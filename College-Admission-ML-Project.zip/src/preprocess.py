import pandas as pd
from sklearn.preprocessing import LabelEncoder
import pickle
import os

def preprocess_data(df, save_encoders=True):
    # Drop ID column
    if "student_id" in df.columns:
        df = df.drop("student_id", axis=1)

    # Encode categorical columns
    label_cols = df.select_dtypes(include=['object']).columns
    encoders = {}

    for col in label_cols:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))
        encoders[col] = le

    # Save encoders
    if save_encoders:
        os.makedirs(os.path.join(os.getcwd(), 'models'), exist_ok=True)
        with open(os.path.join('models','encoders.pkl'), 'wb') as f:
            pickle.dump(encoders, f)

    return df

if __name__ == '__main__':
    df = pd.read_csv(os.path.join('data','College_Admission.csv'))
    df2 = preprocess_data(df)
    print('Preprocessing done. Columns:', df2.columns.tolist())