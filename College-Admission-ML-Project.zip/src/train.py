import pandas as pd
import pickle
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from preprocess import preprocess_data

def train(save_model=True):
    df = pd.read_csv(os.path.join('data','College_Admission.csv'))
    df = preprocess_data(df)

    if 'admission_status' not in df.columns:
        raise ValueError('Target column admission_status not found in dataset.')

    X = df.drop('admission_status', axis=1)
    y = df['admission_status']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)

    if save_model:
        os.makedirs('models', exist_ok=True)
        with open(os.path.join('models','admission_model.pkl'), 'wb') as f:
            pickle.dump(model, f)

    y_pred = model.predict(X_test)
    print('Accuracy:', accuracy_score(y_test, y_pred))
    print('\nClassification Report:\n', classification_report(y_test, y_pred))

if __name__ == '__main__':
    train()