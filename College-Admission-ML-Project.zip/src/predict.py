import pickle
import pandas as pd
import os

# Load model and encoders
model_path = os.path.join('models','admission_model.pkl')
encoders_path = os.path.join('models','encoders.pkl')

if not os.path.exists(model_path) or not os.path.exists(encoders_path):
    raise FileNotFoundError('Model or encoders not found. Run train.py first to create them.')

model = pickle.load(open(model_path, 'rb'))
encoders = pickle.load(open(encoders_path, 'rb'))

def prepare_sample(sample_dict):
    df = pd.DataFrame([sample_dict])
    for col, le in encoders.items():
        if col in df.columns:
            df[col] = le.transform(df[col].astype(str))
        else:
            raise ValueError(f'Missing column in sample: {col}')
    return df

if __name__ == '__main__':
    # Example sample - replace values as needed
    sample = {
        "age": 18,
        "gender": "female",
        "category": "general",
        "state": "karnataka",
        "preferred_stream": "engineering",
        "entrance_exam": "jee",
        "entrance_score": 250,
        "board_percentage": 92.0,
        "extracurricular_score": 8,
        "admission_probability": 0.70,
        "scholarship_eligibility": "yes"
    }

    df_sample = prepare_sample(sample)
    pred = model.predict(df_sample)
    print('Predicted admission_status:', pred[0])