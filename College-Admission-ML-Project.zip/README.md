# College Admission Prediction ML Project

## Structure

```
College-Admission-ML-Project/
├── data/
│   └── College_Admission.csv
├── models/
│   └── (will contain admission_model.pkl and encoders.pkl after training)
├── src/
│   ├── preprocess.py
│   ├── train.py
│   └── predict.py
└── README.md
```

## How to use

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Train model:
   ```
   cd src
   python train.py
   ```

3. Predict using sample:
   ```
   python predict.py
   ```

## Notes
- The dataset `College_Admission.csv` is already included in the `data/` folder.
- After running train.py, the `models/` folder will contain `admission_model.pkl` and `encoders.pkl`.